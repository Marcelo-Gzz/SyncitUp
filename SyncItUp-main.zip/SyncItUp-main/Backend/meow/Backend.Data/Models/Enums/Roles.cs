﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backend.Data.Models.Enums
{
    public enum Roles
    {
        User = 1,
        Manager = 2
    }
}
